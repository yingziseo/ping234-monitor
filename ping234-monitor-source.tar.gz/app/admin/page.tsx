'use client';

import { useState, useEffect } from 'react';
import Terminal from '@/components/Terminal';
import ThemeLanguageSwitch from '@/components/ThemeLanguageSwitch';
import { useMonitorStore } from '@/lib/store';

export default function AdminPage() {
  const {
    adConfig,
    rotatingAds,
    placeholderCount,
    friendLinks,
    setAdConfig,
    addRotatingAd,
    removeRotatingAd,
    updateRotatingAd,
    setPlaceholderCount,
    addFriendLink,
    removeFriendLink,
    updateFriendLink,
    theme
  } = useMonitorStore();

  const [text, setText] = useState(adConfig.text);
  const [url, setUrl] = useState(adConfig.url);
  const [rotatingAdTextZh, setRotatingAdTextZh] = useState('');
  const [rotatingAdTextTw, setRotatingAdTextTw] = useState('');
  const [rotatingAdTextEn, setRotatingAdTextEn] = useState('');
  const [rotatingAdUrlZh, setRotatingAdUrlZh] = useState('');
  const [rotatingAdUrlTw, setRotatingAdUrlTw] = useState('');
  const [rotatingAdUrlEn, setRotatingAdUrlEn] = useState('');
  const [editingAdId, setEditingAdId] = useState<string | null>(null);
  const [placeholderInput, setPlaceholderInput] = useState(placeholderCount.toString());
  const [password, setPassword] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // 友链相关状态
  const [friendTitle, setFriendTitle] = useState('');
  const [friendUrl, setFriendUrl] = useState('');
  const [friendDesc, setFriendDesc] = useState('');
  const [editingLinkId, setEditingLinkId] = useState<string | null>(null);

  useEffect(() => {
    // 应用主题
    if (theme === 'light') {
      document.documentElement.classList.add('light');
    } else {
      document.documentElement.classList.remove('light');
    }
  }, [theme]);

  const handleLogin = () => {
    if (password === 'admin123') {
      setIsAuthenticated(true);
    } else {
      alert('密码错误');
    }
  };

  const handleSave = () => {
    setAdConfig({ text, url });
    alert('顶部广告配置已更新');
  };

  const handleSaveRotatingAd = () => {
    if (rotatingAdTextZh && rotatingAdUrlZh) {
      const adData = {
        text: {
          zh: rotatingAdTextZh,
          tw: rotatingAdTextTw || rotatingAdTextZh,
          en: rotatingAdTextEn || rotatingAdTextZh
        },
        url: {
          zh: rotatingAdUrlZh,
          tw: rotatingAdUrlTw || rotatingAdUrlZh,
          en: rotatingAdUrlEn || rotatingAdUrlZh
        }
      };

      if (editingAdId) {
        updateRotatingAd(editingAdId, adData);
        alert('广告已更新');
        setEditingAdId(null);
      } else {
        addRotatingAd({
          id: Date.now().toString(),
          ...adData
        });
        alert('广告已添加');
      }
      setRotatingAdTextZh('');
      setRotatingAdTextTw('');
      setRotatingAdTextEn('');
      setRotatingAdUrlZh('');
      setRotatingAdUrlTw('');
      setRotatingAdUrlEn('');
    } else {
      alert('请至少填写简体中文的广告内容');
    }
  };

  const handleEditAd = (ad: any) => {
    setRotatingAdTextZh(ad.text?.zh || '');
    setRotatingAdTextTw(ad.text?.tw || '');
    setRotatingAdTextEn(ad.text?.en || '');
    setRotatingAdUrlZh(ad.url?.zh || '');
    setRotatingAdUrlTw(ad.url?.tw || '');
    setRotatingAdUrlEn(ad.url?.en || '');
    setEditingAdId(ad.id);
  };

  const handleUpdatePlaceholderCount = () => {
    const count = parseInt(placeholderInput);
    if (!isNaN(count) && count >= 0 && count <= 10) {
      setPlaceholderCount(count);
      alert(`预留广告位已更新为 ${count} 个`);
    } else {
      alert('请输入0-10之间的数字');
    }
  };

  const handleAddFriendLink = () => {
    if (friendTitle && friendUrl) {
      if (editingLinkId) {
        updateFriendLink(editingLinkId, {
          title: friendTitle,
          url: friendUrl,
          description: friendDesc
        });
        alert('友链已更新');
        setEditingLinkId(null);
      } else {
        addFriendLink({
          id: Date.now().toString(),
          title: friendTitle,
          url: friendUrl,
          description: friendDesc
        });
        alert('友链已添加');
      }
      setFriendTitle('');
      setFriendUrl('');
      setFriendDesc('');
    } else {
      alert('请填写友链名称和链接');
    }
  };

  const handleEditLink = (link: any) => {
    setFriendTitle(link.title);
    setFriendUrl(link.url);
    setFriendDesc(link.description || '');
    setEditingLinkId(link.id);
  };

  return (
    <main className="min-h-screen p-4 md:p-8 overflow-y-auto">
      <div className="mb-4 flex justify-end max-w-5xl mx-auto">
        <ThemeLanguageSwitch />
      </div>
      <Terminal title="admin@ping234.com">
        <div className="max-w-5xl mx-auto">
          <pre className="text-terminal-cyan text-xs md:text-sm mb-6">
{`╔══════════════════════════════════════╗
║   ping234.com - 管理后台            ║
╚══════════════════════════════════════╝`}
          </pre>

          {!isAuthenticated ? (
            <div className="space-y-4">
              <div className="terminal-line">
                <span className="terminal-prompt">$ </span>
                <span>输入管理密码：</span>
              </div>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
                className="terminal-input"
                placeholder="********"
              />
              <button
                onClick={handleLogin}
                className="terminal-button text-terminal-green"
              >
                [登录]
              </button>
            </div>
          ) : (
            <div className="space-y-8">
              {/* 顶部广告配置 */}
              <div className="space-y-4">
                <h3 className="text-terminal-yellow">📢 顶部广告配置</h3>
                <div>
                  <div className="terminal-line mb-2">
                    <span className="terminal-prompt">$ </span>
                    <span>广告文字：</span>
                  </div>
                  <input
                    type="text"
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    className="w-full p-2 bg-black bg-opacity-50 border border-terminal-gray border-opacity-30
                             text-terminal-fg focus:border-terminal-green
                             focus:outline-none font-mono text-sm"
                  />
                </div>

                <div>
                  <div className="terminal-line mb-2">
                    <span className="terminal-prompt">$ </span>
                    <span>跳转链接：</span>
                  </div>
                  <input
                    type="text"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    className="w-full p-2 bg-black bg-opacity-50 border border-terminal-gray border-opacity-30
                             text-terminal-fg focus:border-terminal-green
                             focus:outline-none font-mono text-sm"
                  />
                </div>

                <button
                  onClick={handleSave}
                  className="terminal-button text-terminal-green border-terminal-green"
                >
                  [保存顶部广告]
                </button>
              </div>

              {/* 轮播广告配置 */}
              <div className="space-y-4">
                <h3 className="text-terminal-yellow">💼 轮播广告配置</h3>

                <div className="space-y-3">
                  <div>
                    <div className="terminal-line mb-2">
                      <span className="terminal-prompt">$ </span>
                      <span>广告文字（简体中文）：</span>
                    </div>
                    <input
                      type="text"
                      value={rotatingAdTextZh}
                      onChange={(e) => setRotatingAdTextZh(e.target.value)}
                      placeholder="例如: ✨ 特价优惠"
                      className="w-full p-2 bg-black bg-opacity-50 border border-terminal-gray border-opacity-30
                               text-terminal-fg focus:border-terminal-green
                               focus:outline-none font-mono text-sm"
                    />
                  </div>
                  <div>
                    <div className="terminal-line mb-2">
                      <span className="terminal-prompt">$ </span>
                      <span>广告文字（繁体中文）：</span>
                    </div>
                    <input
                      type="text"
                      value={rotatingAdTextTw}
                      onChange={(e) => setRotatingAdTextTw(e.target.value)}
                      placeholder="例如: ✨ 特價優惠"
                      className="w-full p-2 bg-black bg-opacity-50 border border-terminal-gray border-opacity-30
                               text-terminal-fg focus:border-terminal-green
                               focus:outline-none font-mono text-sm"
                    />
                  </div>
                  <div>
                    <div className="terminal-line mb-2">
                      <span className="terminal-prompt">$ </span>
                      <span>广告文字（英文）：</span>
                    </div>
                    <input
                      type="text"
                      value={rotatingAdTextEn}
                      onChange={(e) => setRotatingAdTextEn(e.target.value)}
                      placeholder="例如: ✨ Special Offer"
                      className="w-full p-2 bg-black bg-opacity-50 border border-terminal-gray border-opacity-30
                               text-terminal-fg focus:border-terminal-green
                               focus:outline-none font-mono text-sm"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <div className="terminal-line mb-2">
                      <span className="terminal-prompt">$ </span>
                      <span>跳转链接（简体中文）：</span>
                    </div>
                    <input
                      type="text"
                      value={rotatingAdUrlZh}
                      onChange={(e) => setRotatingAdUrlZh(e.target.value)}
                      placeholder="https://example.com/zh"
                      className="w-full p-2 bg-black bg-opacity-50 border border-terminal-gray border-opacity-30
                               text-terminal-fg focus:border-terminal-green
                               focus:outline-none font-mono text-sm"
                    />
                  </div>
                  <div>
                    <div className="terminal-line mb-2">
                      <span className="terminal-prompt">$ </span>
                      <span>跳转链接（繁体中文）：</span>
                    </div>
                    <input
                      type="text"
                      value={rotatingAdUrlTw}
                      onChange={(e) => setRotatingAdUrlTw(e.target.value)}
                      placeholder="https://example.com/tw"
                      className="w-full p-2 bg-black bg-opacity-50 border border-terminal-gray border-opacity-30
                               text-terminal-fg focus:border-terminal-green
                               focus:outline-none font-mono text-sm"
                    />
                  </div>
                  <div>
                    <div className="terminal-line mb-2">
                      <span className="terminal-prompt">$ </span>
                      <span>跳转链接（英文）：</span>
                    </div>
                    <input
                      type="text"
                      value={rotatingAdUrlEn}
                      onChange={(e) => setRotatingAdUrlEn(e.target.value)}
                      placeholder="https://example.com/en"
                      className="w-full p-2 bg-black bg-opacity-50 border border-terminal-gray border-opacity-30
                               text-terminal-fg focus:border-terminal-green
                               focus:outline-none font-mono text-sm"
                    />
                  </div>
                </div>

                <button
                  onClick={handleSaveRotatingAd}
                  className="terminal-button text-terminal-green border-terminal-green"
                >
                  {editingAdId ? '[更新广告]' : '[添加广告]'}
                </button>

                {editingAdId && (
                  <button
                    onClick={() => {
                      setEditingAdId(null);
                      setRotatingAdTextZh('');
                      setRotatingAdTextTw('');
                      setRotatingAdTextEn('');
                      setRotatingAdUrlZh('');
                      setRotatingAdUrlTw('');
                      setRotatingAdUrlEn('');
                    }}
                    className="terminal-button text-terminal-yellow border-terminal-yellow ml-2"
                  >
                    [取消编辑]
                  </button>
                )}

                {/* 预留广告位配置 */}
                <div className="mt-4 pt-4 border-t border-terminal-gray border-opacity-30">
                  <div className="terminal-line mb-2">
                    <span className="terminal-prompt">$ </span>
                    <span>预留广告位数量（0-10）：</span>
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      value={placeholderInput}
                      onChange={(e) => setPlaceholderInput(e.target.value)}
                      min="0"
                      max="10"
                      className="w-24 p-2 bg-black bg-opacity-50 border border-terminal-gray border-opacity-30
                               text-terminal-fg focus:border-terminal-green
                               focus:outline-none font-mono text-sm"
                    />
                    <button
                      onClick={handleUpdatePlaceholderCount}
                      className="terminal-button text-terminal-cyan border-terminal-cyan px-4"
                    >
                      [更新]
                    </button>
                  </div>
                  <div className="text-terminal-gray text-xs mt-2">
                    当前预留广告位: {placeholderCount} 个
                  </div>
                </div>
              </div>

              {/* 友情链接管理 */}
              <div className="space-y-4">
                <h3 className="text-terminal-yellow">🔗 友情链接管理</h3>

                <div>
                  <div className="terminal-line mb-2">
                    <span className="terminal-prompt">$ </span>
                    <span>链接名称：</span>
                  </div>
                  <input
                    type="text"
                    value={friendTitle}
                    onChange={(e) => setFriendTitle(e.target.value)}
                    placeholder="例如: Google"
                    className="w-full p-2 bg-black bg-opacity-50 border border-terminal-gray border-opacity-30
                             text-terminal-fg focus:border-terminal-green
                             focus:outline-none font-mono text-sm"
                  />
                </div>

                <div>
                  <div className="terminal-line mb-2">
                    <span className="terminal-prompt">$ </span>
                    <span>链接地址：</span>
                  </div>
                  <input
                    type="text"
                    value={friendUrl}
                    onChange={(e) => setFriendUrl(e.target.value)}
                    placeholder="https://google.com"
                    className="w-full p-2 bg-black bg-opacity-50 border border-terminal-gray border-opacity-30
                             text-terminal-fg focus:border-terminal-green
                             focus:outline-none font-mono text-sm"
                  />
                </div>

                <div>
                  <div className="terminal-line mb-2">
                    <span className="terminal-prompt">$ </span>
                    <span>描述（选填）：</span>
                  </div>
                  <input
                    type="text"
                    value={friendDesc}
                    onChange={(e) => setFriendDesc(e.target.value)}
                    placeholder="例如: 全球最大搜索引擎"
                    className="w-full p-2 bg-black bg-opacity-50 border border-terminal-gray border-opacity-30
                             text-terminal-fg focus:border-terminal-green
                             focus:outline-none font-mono text-sm"
                  />
                </div>

                <button
                  onClick={handleAddFriendLink}
                  className="terminal-button text-terminal-green border-terminal-green"
                >
                  {editingLinkId ? '[更新友链]' : '[添加友链]'}
                </button>

                {editingLinkId && (
                  <button
                    onClick={() => {
                      setEditingLinkId(null);
                      setFriendTitle('');
                      setFriendUrl('');
                      setFriendDesc('');
                    }}
                    className="terminal-button text-terminal-yellow border-terminal-yellow ml-2"
                  >
                    [取消编辑]
                  </button>
                )}

                {/* 当前友链列表 */}
                <div className="mt-6">
                  <h4 className="text-terminal-cyan mb-3">当前友情链接：</h4>
                  <div className="space-y-2">
                    {friendLinks.map((link) => (
                      <div key={link.id} className="p-3 bg-terminal-gray bg-opacity-10 border border-terminal-gray border-opacity-30 rounded flex justify-between items-start">
                        <div className="flex-1">
                          <div className="text-terminal-cyan font-mono">{link.title}</div>
                          <div className="text-terminal-fg text-sm mt-1">{link.url}</div>
                          {link.description && (
                            <div className="text-terminal-gray text-xs mt-1">{link.description}</div>
                          )}
                        </div>
                        <div className="flex gap-2 ml-4">
                          <button
                            onClick={() => handleEditLink(link)}
                            className="text-xs text-terminal-yellow hover:text-terminal-green"
                          >
                            [编辑]
                          </button>
                          <button
                            onClick={() => {
                              if (confirm('确定删除该友链？')) {
                                removeFriendLink(link.id);
                              }
                            }}
                            className="text-xs text-terminal-red hover:text-terminal-magenta"
                          >
                            [删除]
                          </button>
                        </div>
                      </div>
                    ))}
                    {friendLinks.length === 0 && (
                      <div className="text-terminal-gray">暂无友情链接</div>
                    )}
                  </div>
                </div>
              </div>

              {/* 当前轮播广告列表 */}
              <div className="space-y-4">
                <h3 className="text-terminal-yellow">📋 轮播广告列表</h3>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {rotatingAds.map((ad) => (
                    <div key={ad.id} className="p-3 bg-terminal-gray bg-opacity-10 border border-terminal-gray border-opacity-30 rounded flex justify-between items-start">
                      <div className="flex-1">
                        <div className="text-terminal-fg text-sm">{ad.text?.zh || ad.text}</div>
                        <div className="text-terminal-gray text-xs mt-1">{ad.url?.zh || ad.url}</div>
                      </div>
                      <div className="flex gap-2 ml-4">
                        <button
                          onClick={() => handleEditAd(ad)}
                          className="text-xs text-terminal-yellow hover:text-terminal-green"
                        >
                          [编辑]
                        </button>
                        <button
                          onClick={() => {
                            if (confirm('确定删除该广告？')) {
                              removeRotatingAd(ad.id);
                            }
                          }}
                          className="text-xs text-terminal-red hover:text-terminal-magenta"
                        >
                          [删除]
                        </button>
                      </div>
                    </div>
                  ))}
                  {rotatingAds.length === 0 && (
                    <div className="text-terminal-gray">暂无轮播广告</div>
                  )}
                </div>
                <div className="text-terminal-cyan text-sm mt-2">
                  总计: {rotatingAds.length} 个真实广告 + {placeholderCount} 个预留位 = {rotatingAds.length + placeholderCount} 个广告循环
                </div>
              </div>

              <button
                onClick={() => setIsAuthenticated(false)}
                className="terminal-button text-terminal-red border-terminal-red"
              >
                [退出登录]
              </button>
            </div>
          )}
        </div>
      </Terminal>
    </main>
  );
}