'use client';

import { useEffect, useState } from 'react';
import { useMonitorStore } from '@/lib/store';
import { getStatusClass, getStatusText, formatTime, calculateStats, getJitterLevel } from '@/lib/utils';
import { getTranslation } from '@/lib/i18n';

export default function MonitorDisplay() {
  const {
    monitoringDomains,
    isMonitoring,
    interval,
    results,
    history,
    rotatingAds,
    placeholderCount,
    updateResult,
    updateHistory,
    language,
  } = useMonitorStore();

  const t = getTranslation(language);

  const [checkCount, setCheckCount] = useState(0);
  const [sessionStart] = useState(new Date());

  useEffect(() => {
    if (!isMonitoring) return;

    const checkDomains = async () => {
      setCheckCount(prev => prev + 1);

      for (const domain of monitoringDomains) {
        // 模拟检测（实际环境中需要通过API）
        const ping = await checkDomain(domain);
        updateResult(domain, ping);
        updateHistory(domain, ping);
      }
    };

    checkDomains();
    const intervalId = setInterval(checkDomains, interval * 1000);

    return () => clearInterval(intervalId);
  }, [isMonitoring, interval, monitoringDomains, updateResult, updateHistory]);

  async function checkDomain(domain: string): Promise<number> {
    const start = Date.now();

    try {
      // 使用图片加载测试（避免CORS）
      await new Promise((resolve, reject) => {
        const img = new Image();
        const timeout = setTimeout(() => {
          img.src = '';
          reject(new Error('Timeout'));
        }, 5000);

        img.onload = () => {
          clearTimeout(timeout);
          resolve(true);
        };

        img.onerror = () => {
          clearTimeout(timeout);
          // 即使失败也可能是成功的（404但服务器响应了）
          resolve(false);
        };

        img.src = `https://${domain}/favicon.ico?t=${Date.now()}`;
      });

      const elapsed = Date.now() - start;
      return elapsed < 5000 ? elapsed : -1;
    } catch {
      return -1;
    }
  }

  const getSessionTime = () => {
    const now = new Date();
    const diff = now.getTime() - sessionStart.getTime();
    const hours = Math.floor(diff / 3600000);
    const minutes = Math.floor((diff % 3600000) / 60000);
    const seconds = Math.floor((diff % 60000) / 1000);
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  const getOverallStats = () => {
    const allResults = Object.values(results);
    const online = allResults.filter(p => p > 0).length;
    const offline = allResults.filter(p => p <= 0).length;
    const avgPing = online > 0 ?
      allResults.filter(p => p > 0).reduce((a, b) => a + b, 0) / online : 0;

    return { online, offline, avgPing };
  };

  const handleDomainClick = (domain: string) => {
    window.open(`https://${domain}`, '_blank', 'noopener,noreferrer');
  };

  // Generate ads pool with placeholders
  const getAdsPool = () => {
    const pool: any[] = [...rotatingAds];
    for (let i = 0; i < placeholderCount; i++) {
      pool.push({
        id: `placeholder-${i}`,
        text: {
          zh: '📢 投放广告赞助',
          tw: '📢 投放廣告贊助',
          en: '📢 Place Ad Sponsorship'
        },
        url: {
          zh: '',
          tw: '',
          en: ''
        },
        isPlaceholder: true
      });
    }
    return pool;
  };

  // Get ad for specific index (rotating through pool)
  const getAdForIndex = (index: number) => {
    const pool = getAdsPool();
    if (pool.length === 0) return null;
    return pool[index % pool.length];
  };

  const stats = getOverallStats();

  return (
    <div className="space-y-6">
      {/* 状态栏 */}
      <div className="flex flex-wrap gap-4 text-xs md:text-sm text-terminal-gray">
        <span>{t.runningTime}: <span className="text-terminal-green">{getSessionTime()}</span></span>
        <span>{t.checkCount}: <span className="text-terminal-cyan">{checkCount}</span></span>
        <span>{t.online}: <span className="text-terminal-green">{stats.online}</span></span>
        <span>{t.offline}: <span className="text-terminal-red">{stats.offline}</span></span>
        <span>{t.avgDelay}: <span className="text-terminal-yellow">{stats.avgPing.toFixed(0)}ms</span></span>
      </div>

      {/* 结果表格 */}
      <div className="overflow-x-auto">
        <table className="domain-table">
          <thead>
            <tr>
              <th className="w-12">{t.number}</th>
              <th>{t.checkAddress}</th>
              <th className="text-center">{t.status}</th>
              <th className="text-center">{t.delay}</th>
              <th className="text-center hide-mobile">{t.jitter}</th>
              <th className="text-center hide-mobile">{t.packetLoss}</th>
              <th className="hide-mobile">{t.adSponsor}</th>
            </tr>
          </thead>
          <tbody>
            {monitoringDomains.map((domain, index) => {
              const ping = results[domain] || -1;
              const domainHistory = history[domain] || [];
              const domainStats = calculateStats(domainHistory);
              const ad = getAdForIndex(index);

              return (
                <tr key={domain} className="hover:bg-terminal-gray/10 transition-colors">
                  <td className="text-terminal-gray">{index + 1}</td>
                  <td>
                    <button
                      onClick={() => handleDomainClick(domain)}
                      className="text-terminal-cyan hover:text-terminal-green hover:underline
                               transition-colors cursor-pointer text-left"
                    >
                      <span className="truncate block max-w-[200px] md:max-w-none">
                        {domain}
                      </span>
                    </button>
                  </td>
                  <td className={`text-center ${getStatusClass(ping)}`}>
                    {getStatusText(ping)}
                  </td>
                  <td className={`text-center ${getStatusClass(ping)}`}>
                    {formatTime(ping)}
                  </td>
                  <td className="text-center hide-mobile">
                    {domainStats ? (
                      <span className={domainStats.stdev < 30 ? 'text-terminal-green' : 'text-terminal-yellow'}>
                        {getJitterLevel(domainStats.stdev)}
                      </span>
                    ) : '-'}
                  </td>
                  <td className="text-center hide-mobile">
                    {domainStats ? (
                      <span className={domainStats.packetLoss < 10 ? 'text-terminal-green' : 'text-terminal-red'}>
                        {domainStats.packetLoss.toFixed(1)}%
                      </span>
                    ) : '-'}
                  </td>
                  <td className="hide-mobile">
                    {ad ? (
                      <button
                        onClick={() => {
                          if (ad.isPlaceholder) {
                            alert(t.contactAd);
                          } else {
                            const url = typeof ad.url === 'object' ? (ad.url[language] || ad.url.zh || ad.url.en) : ad.url;
                            window.open(url, '_blank');
                          }
                        }}
                        className={`text-xs hover:underline transition-colors cursor-pointer ${
                          ad.isPlaceholder
                            ? 'text-terminal-gray opacity-60 hover:text-terminal-cyan hover:opacity-100'
                            : 'text-terminal-blue hover:text-terminal-cyan'
                        }`}
                      >
                        {typeof ad.text === 'object' ? (ad.text[language] || ad.text.zh || ad.text.en) : ad.text}
                      </button>
                    ) : (
                      <button
                        onClick={() => alert(t.contactAd)}
                        className="text-xs text-terminal-gray opacity-60 hover:text-terminal-cyan hover:opacity-100
                                 hover:underline transition-colors cursor-pointer"
                      >
                        {t.placeAd}
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* 移动端广告显示 */}
      <div className="md:hidden space-y-2">
        {[0, 1, 2].map(index => {
          const ad = getAdForIndex(index);
          if (!ad) return null;

          return (
            <div
              key={ad.id}
              onClick={() => {
                if (ad.isPlaceholder) {
                  alert(t.contactAd);
                } else {
                  const url = typeof ad.url === 'object' ? (ad.url[language] || ad.url.zh || ad.url.en) : ad.url;
                  window.open(url, '_blank');
                }
              }}
              className="bg-terminal-gray bg-opacity-10 border border-terminal-gray border-opacity-30 p-2 rounded
                       text-center text-xs cursor-pointer
                       hover:bg-terminal-gray/20 transition-colors"
              style={{ color: ad.isPlaceholder ? 'rgba(156, 163, 175, 0.6)' : 'rgba(96, 165, 250, 0.8)' }}
            >
              [AD] {typeof ad.text === 'object' ? (ad.text[language] || ad.text.zh || ad.text.en) : ad.text}
            </div>
          );
        })}
      </div>

      {/* 详细网络统计（每10次检测显示） */}
      {checkCount > 0 && checkCount % 10 === 0 && (
        <div className="border-t border-terminal-gray border-opacity-30 pt-4">
          <div className="text-terminal-yellow mb-3">{t.networkQualityReport}</div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs md:text-sm">
            {monitoringDomains.slice(0, 6).map(domain => {
              const domainHistory = history[domain] || [];
              const domainStats = calculateStats(domainHistory);

              if (!domainStats) return null;

              return (
                <div key={domain} className="space-y-1 text-terminal-gray">
                  <div className="text-terminal-cyan font-medium truncate">{domain}</div>
                  <div>{t.min}: {domainStats.min.toFixed(0)}ms</div>
                  <div>{t.max}: {domainStats.max.toFixed(0)}ms</div>
                  <div>{t.avg}: {domainStats.avg.toFixed(0)}ms</div>
                  <div>{t.jitter}: {domainStats.stdev.toFixed(1)}ms</div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}