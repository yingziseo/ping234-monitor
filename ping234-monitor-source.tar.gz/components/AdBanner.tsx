'use client';

import { useMonitorStore } from '@/lib/store';
import { getTranslation } from '@/lib/i18n';

export default function AdBanner() {
  const { adConfig, language } = useMonitorStore();
  const t = getTranslation(language);

  // 根据语言获取不同的广告文本
  const getAdText = () => {
    switch(language) {
      case 'tw':
        return '🚀 高速穩定雲端伺服器 - 月付19元起';
      case 'en':
        return '🚀 Fast & Stable Cloud Server - From $19/mo';
      default:
        return adConfig.text;
    }
  };

  const getAdUrl = () => {
    switch(language) {
      case 'tw':
      case 'en':
        return 'https://example.com/' + language;
      default:
        return adConfig.url;
    }
  };

  const handleClick = () => {
    const url = getAdUrl();
    if (url) {
      window.open(url, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <div
      className="ad-banner mb-4 animate-pulse"
      onClick={handleClick}
    >
      <span className="text-terminal-cyan opacity-80">
        [AD] {getAdText()}
      </span>
    </div>
  );
}