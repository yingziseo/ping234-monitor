export function getStatusClass(ping: number): string {
  if (ping < 0) return 'status-offline';
  if (ping < 100) return 'status-excellent';
  if (ping < 300) return 'status-good';
  if (ping < 500) return 'status-medium';
  return 'status-poor';
}

export function getStatusText(ping: number): string {
  if (ping < 0) return '离线';
  if (ping < 100) return '优秀';
  if (ping < 300) return '良好';
  if (ping < 500) return '中等';
  return '较慢';
}

export function calculateStats(history: number[]) {
  const validPings = history.filter(p => p > 0);
  if (validPings.length === 0) return null;

  const avg = validPings.reduce((a, b) => a + b, 0) / validPings.length;
  const min = Math.min(...validPings);
  const max = Math.max(...validPings);

  // 计算标准差（抖动）
  const variance = validPings.reduce((sum, val) =>
    sum + Math.pow(val - avg, 2), 0) / validPings.length;
  const stdev = Math.sqrt(variance);

  const packetLoss = ((history.length - validPings.length) / history.length) * 100;

  return {
    avg,
    min,
    max,
    stdev,
    packetLoss,
    samples: history.length,
  };
}

export function getJitterLevel(stdev: number): string {
  if (stdev < 10) return '稳定';
  if (stdev < 30) return '轻微';
  if (stdev < 50) return '中等';
  return '严重';
}

export function formatTime(ms: number): string {
  if (ms < 0) return 'N/A';
  return `${ms.toFixed(0)}ms`;
}