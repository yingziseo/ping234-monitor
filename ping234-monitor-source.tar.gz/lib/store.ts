import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Language } from './i18n';

interface AdConfig {
  text: string;
  url: string;
}

interface RotatingAd {
  id: string;
  text: {
    zh: string;
    tw: string;
    en: string;
  };
  url: {
    zh: string;
    tw: string;
    en: string;
  };
  isPlaceholder?: boolean;
}

interface FriendLink {
  id: string;
  title: string;
  url: string;
  description?: string;
}

interface MonitorStore {
  selectedType: 'domestic' | 'international' | 'custom' | null;
  customDomains: string[];
  monitoringDomains: string[];
  isMonitoring: boolean;
  interval: number;
  results: Record<string, number>;
  history: Record<string, number[]>;
  adConfig: AdConfig;
  rotatingAds: RotatingAd[];
  placeholderCount: number;
  friendLinks: FriendLink[];
  theme: 'light' | 'dark';
  language: Language;

  setSelectedType: (type: 'domestic' | 'international' | 'custom' | null) => void;
  setCustomDomains: (domains: string[]) => void;
  setMonitoringDomains: (domains: string[]) => void;
  setIsMonitoring: (monitoring: boolean) => void;
  setInterval: (interval: number) => void;
  updateResult: (domain: string, ping: number) => void;
  updateHistory: (domain: string, ping: number) => void;
  setAdConfig: (config: AdConfig) => void;
  addRotatingAd: (ad: RotatingAd) => void;
  removeRotatingAd: (id: string) => void;
  updateRotatingAd: (id: string, ad: Partial<RotatingAd>) => void;
  setPlaceholderCount: (count: number) => void;
  addFriendLink: (link: FriendLink) => void;
  removeFriendLink: (id: string) => void;
  updateFriendLink: (id: string, link: Partial<FriendLink>) => void;
  setTheme: (theme: 'light' | 'dark') => void;
  setLanguage: (language: Language) => void;
  reset: () => void;
}

export const useMonitorStore = create<MonitorStore>()(
  persist(
    (set) => ({
  selectedType: null,
  customDomains: [],
  monitoringDomains: [],
  isMonitoring: false,
  interval: 5,
  results: {},
  history: {},
  adConfig: {
    text: '🚀 高速稳定云服务器 - 月付19元起',
    url: 'https://example.com',
  },
  rotatingAds: [
    {
      id: '1',
      text: {
        zh: '✨ 百度推广 - SEO优化服务',
        tw: '✨ 百度推廣 - SEO優化服務',
        en: '✨ Baidu Ads - SEO Optimization'
      },
      url: {
        zh: 'https://baidu.com',
        tw: 'https://baidu.com',
        en: 'https://baidu.com'
      }
    },
    {
      id: '2',
      text: {
        zh: '🌐 Google Ads - 全球推广',
        tw: '🌐 Google Ads - 全球推廣',
        en: '🌐 Google Ads - Global Marketing'
      },
      url: {
        zh: 'https://ads.google.com/zh',
        tw: 'https://ads.google.com/tw',
        en: 'https://ads.google.com'
      }
    },
    {
      id: '3',
      text: {
        zh: '🛍️ 淘宝特价 - 限时秒杀',
        tw: '🛍️ 淘寶特價 - 限時秒殺',
        en: '🛍️ Taobao Deals - Limited Time'
      },
      url: {
        zh: 'https://taobao.com',
        tw: 'https://taobao.com',
        en: 'https://world.taobao.com'
      }
    },
  ],
  placeholderCount: 2,
  friendLinks: [
    { id: '1', title: 'GitHub', url: 'https://github.com', description: '全球最大代码托管平台' },
    { id: '2', title: 'Google', url: 'https://google.com', description: '全球最大搜索引擎' },
    { id: '3', title: 'Stack Overflow', url: 'https://stackoverflow.com', description: '技术问答社区' },
    { id: '4', title: 'MDN', url: 'https://developer.mozilla.org', description: 'Web开发文档' },
    { id: '5', title: 'V2EX', url: 'https://v2ex.com', description: '创意工作者社区' },
  ],
  theme: 'dark',
  language: 'zh' as Language,

  setSelectedType: (type) => set({ selectedType: type }),
  setCustomDomains: (domains) => set({ customDomains: domains }),
  setMonitoringDomains: (domains) => set({ monitoringDomains: domains }),
  setIsMonitoring: (monitoring) => set({ isMonitoring: monitoring }),
  setInterval: (interval) => set({ interval }),

  updateResult: (domain, ping) =>
    set((state) => ({
      results: { ...state.results, [domain]: ping }
    })),

  updateHistory: (domain, ping) =>
    set((state) => {
      const history = { ...state.history };
      if (!history[domain]) {
        history[domain] = [];
      }
      history[domain].push(ping);
      if (history[domain].length > 100) {
        history[domain].shift();
      }
      return { history };
    }),

  setAdConfig: (config) => set({ adConfig: config }),

  addRotatingAd: (ad) =>
    set((state) => ({
      rotatingAds: [...state.rotatingAds, ad]
    })),

  removeRotatingAd: (id) =>
    set((state) => ({
      rotatingAds: state.rotatingAds.filter(ad => ad.id !== id)
    })),

  updateRotatingAd: (id, updatedAd) =>
    set((state) => ({
      rotatingAds: state.rotatingAds.map(ad =>
        ad.id === id ? { ...ad, ...updatedAd } : ad
      )
    })),

  setPlaceholderCount: (count) => set({ placeholderCount: count }),

  addFriendLink: (link) =>
    set((state) => ({
      friendLinks: [...state.friendLinks, link]
    })),

  removeFriendLink: (id) =>
    set((state) => ({
      friendLinks: state.friendLinks.filter(link => link.id !== id)
    })),

  updateFriendLink: (id, updatedLink) =>
    set((state) => ({
      friendLinks: state.friendLinks.map(link =>
        link.id === id ? { ...link, ...updatedLink } : link
      )
    })),

  setTheme: (theme) => set({ theme }),
  setLanguage: (language) => set({ language }),

  reset: () => set({
    selectedType: null,
    monitoringDomains: [],
    isMonitoring: false,
    results: {},
    history: {},
  }),
    }),
    {
      name: 'monitor-storage',
      partialize: (state) => ({
        theme: state.theme,
        language: state.language,
        friendLinks: state.friendLinks,
        rotatingAds: state.rotatingAds,
        placeholderCount: state.placeholderCount,
        adConfig: state.adConfig,
      }),
    }
  )
);